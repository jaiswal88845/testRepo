package com.example.cm_serets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmSeretsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmSeretsApplication.class, args);
	}

}
