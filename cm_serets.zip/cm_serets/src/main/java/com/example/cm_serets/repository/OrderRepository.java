package com.example.cm_serets.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.cm_serets.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {
}
