package com.example.cm_serets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class CmSeretsApplicationTests {

	//@Test
	void contextLoads() {
	}

}
